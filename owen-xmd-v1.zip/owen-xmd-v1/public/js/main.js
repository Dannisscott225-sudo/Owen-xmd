// ==== Gestion des onglets Pair Code / QR Code ====
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

tabButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    tabButtons.forEach((b) => b.classList.remove('active'));
    tabContents.forEach((c) => c.classList.remove('active'));

    btn.classList.add('active');
    document.getElementById(`${btn.dataset.tab}-tab`).classList.add('active');
  });
});

// ==== Pair Code ====
const getPairCodeBtn = document.getElementById('getPairCode');
const phoneInput = document.getElementById('phone');
const pairResult = document.getElementById('pairResult');
const pairCodeValue = document.getElementById('pairCodeValue');

getPairCodeBtn.addEventListener('click', async () => {
  const number = phoneInput.value.trim();
  if (!number) {
    alert('Entre ton numéro WhatsApp (avec indicatif pays, sans le +).');
    return;
  }

  getPairCodeBtn.textContent = '⏳ Génération...';
  getPairCodeBtn.disabled = true;

  try {
    const res = await fetch('/api/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number }),
    });
    const data = await res.json();

    if (data.ok) {
      pairCodeValue.textContent = data.code;
      pairResult.classList.remove('hidden');
    } else {
      alert(data.error || 'Une erreur est survenue.');
    }
  } catch (err) {
    alert('Impossible de contacter le serveur.');
  } finally {
    getPairCodeBtn.textContent = '✨ OBTENIR LE CODE';
    getPairCodeBtn.disabled = false;
  }
});

// ==== QR Code ====
const getQrBtn = document.getElementById('getQr');
const qrResult = document.getElementById('qrResult');
const qrImage = document.getElementById('qrImage');

getQrBtn.addEventListener('click', async () => {
  getQrBtn.textContent = '⏳ Génération...';
  getQrBtn.disabled = true;

  try {
    const res = await fetch('/api/qr');
    const data = await res.json();

    if (data.ok) {
      qrImage.src = data.qr;
      qrResult.classList.remove('hidden');
    } else {
      alert(data.error || 'Une erreur est survenue.');
    }
  } catch (err) {
    alert('Impossible de contacter le serveur.');
  } finally {
    getQrBtn.textContent = '▣ GÉNÉRER LE QR CODE';
    getQrBtn.disabled = false;
  }
});
