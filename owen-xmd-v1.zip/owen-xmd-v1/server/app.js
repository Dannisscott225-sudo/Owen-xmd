const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const QRCode = require('qrcode');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    Browsers,
    DisconnectReason,
} = require('@whiskeysockets/baileys');
const pino = require('pino');

const config = require('../config');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const TMP_DIR = path.join(__dirname, '..', 'temp');
fs.ensureDirSync(TMP_DIR);

/**
 * Nettoie un numéro de téléphone (garde seulement les chiffres).
 */
function cleanNumber(num) {
    return String(num || '').replace(/[^0-9]/g, '');
}

/**
 * Route : POST /api/pair
 * Body: { number: "2250000000000" }
 * Renvoie un code de pairing WhatsApp à entrer dans Appareils liés.
 */
app.post('/api/pair', async (req, res) => {
    const number = cleanNumber(req.body.number);
    if (!number || number.length < 8) {
        return res.status(400).json({ ok: false, error: 'Numéro invalide.' });
    }

    const sessionPath = path.join(TMP_DIR, `pair-${number}-${Date.now()}`);
    await fs.ensureDir(sessionPath);

    try {
        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            auth: state,
            browser: Browsers.macOS(config.BOT_NAME),
        });

        sock.ev.on('creds.update', saveCreds);

        if (!sock.authState.creds.registered) {
            const code = await sock.requestPairingCode(number);
            res.json({ ok: true, code, sessionPath: path.basename(sessionPath) });
        }

        sock.ev.on('connection.update', async (update) => {
            const { connection } = update;
            if (connection === 'open') {
                console.log(`✓ Session liée avec succès pour ${number}`);
                // À ce stade : déplace sessionPath vers ./session (dossier utilisé par index.js)
                await fs.copy(sessionPath, path.join(__dirname, '..', 'session'), { overwrite: true });
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ ok: false, error: "Impossible de générer le code de pairing." });
    }
});

/**
 * Route : GET /api/qr
 * Renvoie un QR code (image base64) à scanner depuis WhatsApp.
 */
app.get('/api/qr', async (req, res) => {
    const sessionPath = path.join(TMP_DIR, `qr-${Date.now()}`);
    await fs.ensureDir(sessionPath);

    try {
        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            auth: state,
            browser: Browsers.macOS(config.BOT_NAME),
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('connection.update', async (update) => {
            const { connection, qr } = update;

            if (qr && !res.headersSent) {
                const qrImage = await QRCode.toDataURL(qr);
                res.json({ ok: true, qr: qrImage });
            }

            if (connection === 'open') {
                console.log('✓ Session liée avec succès via QR');
                await fs.copy(sessionPath, path.join(__dirname, '..', 'session'), { overwrite: true });
            }

            if (connection === 'close' && !res.headersSent) {
                res.status(500).json({ ok: false, error: 'QR expiré, réessaie.' });
            }
        });
    } catch (err) {
        console.error(err);
        if (!res.headersSent) {
            res.status(500).json({ ok: false, error: 'Impossible de générer le QR code.' });
        }
    }
});

app.get('/api/status', (req, res) => {
    res.json({ ok: true, bot: config.BOT_NAME, version: config.VERSION });
});

app.listen(config.PORT, () => {
    console.log(`✓ Serveur web ${config.BOT_NAME} lancé sur le port ${config.PORT}`);
});
